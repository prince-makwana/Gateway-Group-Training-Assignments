﻿using Course.Microservice.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Course.Microservice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        // GET: api/<CourseController>
        [HttpGet]
        [HttpGet("getCourse")]
        public ActionResult<IEnumerable<string>> Get()
        {
            Courses courses = GetStaticData();
            return Ok(courses);
        }

        //// GET api/<CourseController>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/<CourseController>
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/<CourseController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<CourseController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}

        private Courses GetStaticData()
        {
            Courses courses = new Courses()
            {
                Id = 1,
                CourseName = ".NET Core",
                CourseCredits = 30,
                CourseTrainer = "XYZ ABC"
            };

            return courses;
        }
    }
}
